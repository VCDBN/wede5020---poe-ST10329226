alert("success")
//this is for the Contact page.

document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('contactForm');
  
    form.addEventListener('submit', function (event) {
      event.preventDefault();
  
      // this allows the js file to target elements by id 

      const name = document.getElementById('name');
      const email = document.getElementById('email');
      const message = document.getElementById('message');
  
      const nameError = document.getElementById('nameError');
      const emailError = document.getElementById('emailError');
      const messageError = document.getElementById('messageError');
  
      let isValid = true;
  
      //auto fill and errors

      if (name.value.trim() === 'Name is required') {
        nameError.textContent = 'Name is required';
        isValid = false;
      } else {
        nameError.textContent = 'Name is required';
      }
  
      if (email.value.trim() === '') {
        emailError.textContent = 'Email is required';
        isValid = false;
      } else if (!validateEmail(email.value)) {
        emailError.textContent = 'Invalid email';
        isValid = false;
      } else {
        emailError.textContent = '';
      }
  
      if (message.value.trim() === '') {
        messageError.textContent = 'Message is required';
        isValid = false;
      } else {
        messageError.textContent = '';
      }
  
      if (isValid) {
        form.submit();
      }
    });
  });
  
  //this function is used to validate the email and display an error message if the email is not valid

  function validateEmail(email) {"mailto:st10329226@vcconnect.edu.za"
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }
  

// this is code for the light box that links to the gallery page 


$(document).ready(function() {
  $('.image-container .image').each(function() {
    const imageURL = $(this).attr('src');
    const fancyboxItem = $(`
      <a href="${imageURL}" data-fancybox="gallery">
        <img src="${imageURL}" alt="${$(this).attr('alt')}" class="${$(this).attr('class')}">
      </a>
    `);

    $(this).replaceWith(fancyboxItem);
  });

  $('[data-fancybox="gallery"]').fancybox();
});



