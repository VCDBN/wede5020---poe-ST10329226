
const fs = require('fs');

const pages = [
  { url: 'http://127.0.0.1:5500/Homepage.html', lastmod: '2023-06-18', changefreq: 'monthly' },
  { url: 'http://127.0.0.1:5500/Gallary.html', lastmod: '2023-06-18', changefreq: 'monthly' },
  { url: 'http://127.0.0.1:5500/contacts.html', lastmod: '2023-06-18', changefreq: 'monthly' },
  { url: 'https://www.example.com/Products.html', lastmod: '2023-06-18', changefreq: 'monthly' },
  { url: 'https://www.example.com/about.html', lastmod: '2023-06-18', changefreq: 'monthly' },
  { url: 'https://www.example.com/News.html', lastmod: '2023-06-18', changefreq: 'monthly' },
];

function generateSitemap(pages) {
  let sitemap = `<?xml version="1.0" encoding="UTF-8"?>\n`;
  sitemap += `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n`;

  pages.forEach(page => {
    sitemap += `  <url>\n`;
    sitemap += `    <loc>${page.url}</loc>\n`;
    sitemap += `    <lastmod>${page.lastmod}</lastmod>\n`;
    sitemap += `    <changefreq>${page.changefreq}</changefreq>\n`;
    sitemap += `  </url>\n`;
  });

  sitemap += `</urlset>`;

  return sitemap;
}

const sitemap = generateSitemap(pages);
fs.writeFileSync('sitemap.xml', sitemap);
console.log('Sitemap generated successfully');

